document.addEventListener('DOMContentLoaded', () => {
    const bookmarksContainer = document.getElementById('bookmarks');
    const addFolderBtn = document.getElementById('addFolderBtn');
    const addBookmarkBtn = document.getElementById('addBookmarkBtn');
    const editBtn = document.getElementById('editBtn');
    const lockBtn = document.getElementById('lockBtn');
    let viewMode  = true;


    /* ----------------------------- */
    /* ----------------------------- */
    /* ------ Password System ------ */
    /* ----------------------------- */
    /* ----------------------------- */
    const passwordFormContainer = document.getElementById('password-form');
    const setPasswordForm = document.getElementById('set-password-form');
    const navBar = document.getElementById('nav-bar');
    const bookmarkManager = document.getElementById('bookmark-manager');

    const passwordcheckFormContainer = document.getElementById('passwordCheck');
    const passwordCheckForm = document.getElementById('check-password-form');

    const passwordCheckOpen = localStorage.getItem('passwordCheckOpen');
    
    // Hide form if password already exists
    if (localStorage.getItem('savedPassword')) {
        if (passwordCheckOpen == 'true') {
            passwordFormContainer.style.display = 'none';
            navBar.style.display = 'none';
            bookmarkManager.style.display = 'none';
            passwordcheckFormContainer.style.display = 'block';
        }
        else {
            passwordFormContainer.style.display = 'none';
            navBar.style.display = 'flex';
            bookmarkManager.style.display = 'block';
            passwordcheckFormContainer.style.display = 'none';
        }
    }

    setPasswordForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const password = document.getElementById('set-password').value.trim();
        const confirmPassword = document.getElementById('confirm-password').value.trim();

        if (password !== confirmPassword) {
            alert('Passwords do not match.');
            return;
        }

        localStorage.setItem('savedPassword', password);
        passwordFormContainer.style.display = 'none';
        navBar.style.display = 'flex';
        bookmarkManager.style.display = 'block';
    });

    lockBtn.addEventListener('click', () => {
        passwordcheckFormContainer.style.display = 'block';
        navBar.style.display = 'none';
        bookmarkManager.style.display = 'none';
        localStorage.setItem('passwordCheckOpen', 'true');
    });
    
    passwordCheckForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const passwordInput = document.getElementById('check-password');
        const inputPassword = document.getElementById('check-password').value.trim();
        const savedPassword = localStorage.getItem('savedPassword');
        const errorElement = document.getElementById('checkpassError');

        if (inputPassword !== savedPassword) {
            errorElement.style.display = 'block';
            errorElement.textContent = "Wrong password.";
            errorElement.style.color = "red";
            return;
        }
        localStorage.setItem('passwordCheckOpen', 'false'); // Mark as closed
        errorElement.style.display = 'none';
        passwordInput.value = '';
        passwordFormContainer.style.display = 'none';
        navBar.style.display = 'flex';
        bookmarkManager.style.display = 'block';
        passwordcheckFormContainer.style.display = 'none';
    });

    /* ----------------------------- */
    /* ----------------------------- */
    /* ------ Bookmark System ------ */
    /* ----------------------------- */
    /* ----------------------------- */
    const storageKey = 'bookmarkItems';
    let editing = false;

    document.getElementById('settingsBtn').addEventListener('click', () => {
        if (chrome.runtime.openOptionsPage) {
            chrome.runtime.openOptionsPage();
        } else {
            // Fallback for older versions of Chrome
            window.open(chrome.runtime.getURL('options.html'));
        }
    });

    function setHoverEffect(element) {
        function onMouseEnter() {
            if (editing) element.style.backgroundColor = '#444';
        }
        function onMouseLeave() {
            element.style.backgroundColor = 'transparent';
        }
        element.addEventListener('mouseenter', onMouseEnter);
        element.addEventListener('mouseleave', onMouseLeave);
        element._hoverHandlers = { onMouseEnter, onMouseLeave };
    }

    function removeHoverEffect(element) {
        if (element._hoverHandlers) {
            element.removeEventListener('mouseenter', element._hoverHandlers.onMouseEnter);
            element.removeEventListener('mouseleave', element._hoverHandlers.onMouseLeave);
            delete element._hoverHandlers;
            element.style.backgroundColor = 'transparent';
        }
    }

    // New function for creating the drag icon
    function createDragIcon() {
        const dragIcon = document.createElement('i');
        dragIcon.className = 'fas fa-grip-vertical'; // 6-dot grab icon
        dragIcon.style.marginRight = '10px'; // Space between grab icon and item
        dragIcon.style.cursor = 'move'; // Change the cursor to indicate it's draggable
        dragIcon.style.visibility = editing ? 'visible' : 'hidden'; // Only visible in edit mode
        return dragIcon;
    }

    function createDeleteButton(targetElement) {
        const btn = document.createElement('button');
        const icon = document.createElement('i');
        icon.className = 'fas fa-trash';
        icon.style.fontSize = '12px'; // Icon size
        icon.style.color = '#fff'; // White color
    
        btn.appendChild(icon);
        btn.style.background = 'transparent';
        btn.style.border = 'none';
        btn.style.cursor = 'pointer';
        btn.title = 'Delete';
        btn.classList.add('delete-btn');
    
        // Visibility
        btn.style.display = editing ? 'inline' : 'none';
    
        // Alignment
        btn.style.marginLeft = '4px';  // space between button and folder name or chevron
        btn.style.marginRight = '0';    // aligns tightly to the edge if parent is flexed
        btn.style.padding = '4px';
        btn.style.flexShrink = '0';     // prevents squishing
    
        btn.addEventListener('click', (e) => {
            e.stopPropagation();

            const folderContents = targetElement.closest('.folder-contents');
            targetElement.remove();

            if (folderContents) {
                // Remove any existing "Empty" labels first to avoid duplicates
                const existingEmpty = folderContents.querySelectorAll('div');
                existingEmpty.forEach(div => {
                    if (div.textContent.trim() === 'Empty') {
                        div.remove();
                    }
                });

                // Check if any bookmark items remain (assuming bookmark-item class for both bookmarks and folders)
                const remainingItems = folderContents.querySelectorAll('.bookmark-item');

                if (remainingItems.length === 0) {
                    // Create and append the "Empty" label
                    const emptyLabel = document.createElement('div');
                    emptyLabel.textContent = 'Empty';
                    emptyLabel.style.color = 'rgba(255, 255, 255, 0.4)';
                    emptyLabel.style.marginLeft = '20px';
                    emptyLabel.style.marginTop = '10px';
                    folderContents.appendChild(emptyLabel);
                }
            }

            saveAllItems();
        });

        return btn;
    }

    function saveAllItems() {
        const items = [];

        function serializeItem(item) {
            if (item.classList.contains('folder')) {
                const folderName = item.querySelector('.folder-name').textContent;
                const folderContents = item.querySelector('.folder-contents');
                const isOpen = folderContents.style.display === 'block';

                const contents = [];
                Array.from(folderContents.children).forEach(child => {
                    const result = serializeItem(child);
                    if (result) contents.push(result);
                });

                return {
                    type: 'folder',
                    name: folderName,
                    isOpen: isOpen,
                    contents: contents
                };
            }

            if (item.classList.contains('bookmark-item')) {
                const titleElem = item.querySelector('.bookmark-title');
                const title = titleElem?.textContent;
                const url = titleElem?.href;
                const favicon = item.querySelector('img')?.src;

                return {
                    type: 'bookmark',
                    title,
                    url,
                    favicon
                };
            }

            return null;
        }

        Array.from(bookmarksContainer.children).forEach(item => {
            const result = serializeItem(item);
            if (result) items.push(result);
        });

        localStorage.setItem(storageKey, JSON.stringify(items));
    }


    function loadItems() {
        const items = JSON.parse(localStorage.getItem(storageKey)) || [];
        bookmarksContainer.innerHTML = '';

        function renderItem(item, container) {
            if (item.type === 'folder') {
                const folderElement = createFolderElement(item.name, item.isOpen, [], true); // skipEmptyCheck = true
                container.appendChild(folderElement);

                const folderContents = folderElement.querySelector('.folder-contents');
                item.contents.forEach(childItem => renderItem(childItem, folderContents));

                // If folder is still empty after loading
                if (folderContents.children.length === 0) {
                    const emptyLabel = document.createElement('div');
                    emptyLabel.className = 'empty-label';
                    emptyLabel.textContent = 'Empty';
                    emptyLabel.style.color = 'rgba(255, 255, 255, 0.4)';
                    emptyLabel.style.marginLeft = '40px';
                    emptyLabel.style.marginTop = '10px';
                    folderContents.appendChild(emptyLabel);
                }
            } else if (item.type === 'bookmark') {
                const bookmarkItem = createBookmarkElement(item.title, item.url, item.favicon);
                container.appendChild(bookmarkItem);
            }
        }

        items.forEach(item => renderItem(item, bookmarksContainer));
    }

    function createFolderElement(name = 'New Folder', isOpen = false, contents = [], skipEmptyCheck = false) {
        const folderItem = document.createElement('div');
        folderItem.className = 'bookmark-item folder';
        folderItem.style.display = 'block';

        const headerRow = document.createElement('div');
        headerRow.className = 'folder-header';
        headerRow.style.display = 'flex';
        headerRow.style.alignItems = 'center';
        headerRow.style.justifyContent = 'space-between';

        const leftSection = document.createElement('div');
        leftSection.style.display = 'flex';
        leftSection.style.alignItems = 'center';
        leftSection.style.flexGrow = '1';

        const folderIcon = document.createElement('i');
        folderIcon.className = 'fas fa-folder';
        folderIcon.style.pointerEvents = 'none';

        const folderName = document.createElement('span');
        folderName.className = 'folder-name';
        folderName.textContent = name;
        folderName.spellcheck = false;
        folderName.style.marginLeft = '8px';
        folderName.style.userSelect = 'none';
        folderName.style.cursor = 'default';
        folderName.style.backgroundColor = 'transparent';
        folderName.style.flexGrow = '1';

        if (editing) setHoverEffect(folderName);

        folderName.addEventListener('click', () => {
            if (editing && !folderName.isContentEditable) {
                folderName.contentEditable = true;
                folderName.style.cursor = 'text';
                headerRow.style.backgroundColor = '#444';
                folderName.style.backgroundColor = '#333';
                folderName.focus();
            }
        });

        folderName.addEventListener('focus', () => {
            if (editing) {
                folderName.style.cursor = 'text';
                headerRow.style.backgroundColor = '#444';
                folderName.style.backgroundColor = '#333';
            }
        });

        folderName.addEventListener('blur', () => {
            if (editing) {
                folderName.contentEditable = false;
                folderName.style.cursor = 'default';
                headerRow.style.backgroundColor = 'transparent';
                folderName.style.backgroundColor = 'transparent';
                folderName.style.userSelect = 'none';
                if (folderName.textContent.trim() === '') {
                    folderName.textContent = 'Untitled Folder';
                }
                saveAllItems();
            }
        });

        folderName.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && editing) {
                e.preventDefault();
                folderName.blur();
            }
        });

        // Create drag icon and append it to the left section
        const dragIcon = createDragIcon();
        leftSection.appendChild(dragIcon);
        
        const folderOpenIcon = document.createElement('i');
        folderOpenIcon.className = isOpen ? 'fas fa-chevron-down' : 'fas fa-chevron-left';
        folderOpenIcon.style.cursor = 'pointer';

        folderOpenIcon.addEventListener('click', () => {
            const open = folderContents.style.display === 'block';
            folderContents.style.display = open ? 'none' : 'block';
            folderOpenIcon.className = open ? 'fas fa-chevron-left' : 'fas fa-chevron-down';
            saveAllItems();
        });

        // Trash Bin Icon (New)
        const trashBinIcon = document.createElement('i');
        trashBinIcon.className = 'fas fa-trash';
        trashBinIcon.style.cursor = 'pointer';
        trashBinIcon.style.marginLeft = '10px';
        trashBinIcon.style.display = 'none'; // Hide initially

        trashBinIcon.addEventListener('click', () => {
        if (editing) {
            const parentFolderContents = folderItem.parentElement; // Should be the `.folder-contents` div
            folderItem.remove();

            // Only add empty label if parent is a folder container
            if (parentFolderContents && 
                parentFolderContents.classList.contains('folder-contents') && 
                parentFolderContents.children.length === 0) {
                
                const emptyLabel = document.createElement('div');
                emptyLabel.textContent = 'Empty';
                emptyLabel.style.color = 'rgba(255, 255, 255, 0.4)';
                emptyLabel.style.marginLeft = '20px';
                emptyLabel.style.marginTop = '10px';
                parentFolderContents.appendChild(emptyLabel);
            }

            saveAllItems();
        }
    });


        leftSection.appendChild(folderIcon);
        leftSection.appendChild(folderName);

        headerRow.appendChild(leftSection);
        headerRow.appendChild(folderOpenIcon);

        // Append the trash bin after the folder name
        headerRow.appendChild(trashBinIcon);

        const folderContents = document.createElement('div');
        folderContents.className = 'folder-contents';
        folderContents.style.display = isOpen ? 'block' : 'none';
        folderContents.style.marginLeft = '-15px';
        folderContents.style.marginTop = '10px';

        if (!skipEmptyCheck && contents.length === 0) {
            const emptyLabel = document.createElement('div');
            emptyLabel.textContent = 'Empty';
            emptyLabel.style.color = 'rgba(255, 255, 255, 0.4)';
            emptyLabel.style.marginLeft = '40px';
            emptyLabel.style.marginTop = '10px';
            folderContents.appendChild(emptyLabel);
        } else {
            contents.forEach(bookmark => {
            try {
                if (bookmark && bookmark.title && bookmark.url && bookmark.favicon) {
                    addBookmarkToFolder(bookmark.title, bookmark.url, bookmark.favicon, folderContents);
                } else {
                    console.warn('Invalid bookmark skipped:', bookmark);
                }
            } catch (err) {
                console.error('Error adding bookmark to folder:', err, bookmark);
            }
        });
        }

        folderItem.appendChild(headerRow);
        folderItem.appendChild(folderContents);

        return folderItem;
    }
    function addBookmarkToFolder(title, url, favicon, container) {
        const item = createBookmarkElement(title, url, favicon);
        container.appendChild(item);
    }

    function createBookmarkElement(title, url, favicon) {
        const bookmarkItem = document.createElement('div');
        bookmarkItem.className = 'bookmark-item';
        bookmarkItem.style.display = 'flex';
        bookmarkItem.style.alignItems = 'center';
        bookmarkItem.style.justifyContent = 'space-between';

        const leftPart = document.createElement('div');
        leftPart.style.display = 'flex';
        leftPart.style.alignItems = 'center';
        leftPart.style.flexGrow = '1';

        const dragIcon = createDragIcon();
        leftPart.appendChild(dragIcon);

        // Only create and append the icon if favicon is truthy and non-empty
        if (favicon && favicon.trim() !== '') {
            const bookmarkIcon = document.createElement('img');
            bookmarkIcon.src = favicon;
            bookmarkIcon.alt = 'Bookmark Icon';
            bookmarkIcon.style.marginLeft = '-2px';
            bookmarkIcon.style.marginRight = '8px';
            leftPart.appendChild(bookmarkIcon);
        }
        // If no favicon, no image element is added at all

        const bookmarkTitle = document.createElement('a');
        bookmarkTitle.className = 'bookmark-title';
        bookmarkTitle.href = url;
        bookmarkTitle.textContent = title;
        bookmarkTitle.style.cursor = editing ? 'text' : 'pointer';

        bookmarkTitle.addEventListener('click', (e) => {
            if (editing) return;
            e.preventDefault();
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs.length === 0) return;
                const currentTab = tabs[0];
                chrome.tabs.create({
                    url: url,
                    index: currentTab.index + 1,
                    windowId: currentTab.windowId,
                    active: true,
                });
            });
        });

        leftPart.appendChild(bookmarkTitle);

        const deleteBtn = createDeleteButton(bookmarkItem);

        bookmarkItem.appendChild(leftPart);
        bookmarkItem.appendChild(deleteBtn);

        return bookmarkItem;
    }



    addFolderBtn.addEventListener('click', () => {
        const newFolder = createFolderElement();
        bookmarksContainer.insertBefore(newFolder, bookmarksContainer.firstChild);
        const nameSpan = newFolder.querySelector('.folder-name');
        nameSpan.contentEditable = true;
        nameSpan.style.cursor = 'text';
        nameSpan.focus();
        setHoverEffect(nameSpan);
        const range = document.createRange();
        range.selectNodeContents(nameSpan);
        const selection = window.getSelection();
        selection.removeAllRanges();
        selection.addRange(range);

        nameSpan.addEventListener('blur', () => {
            if (!editing) {
                nameSpan.contentEditable = false;
                nameSpan.style.cursor = 'default';
                nameSpan.style.backgroundColor = 'transparent';
                nameSpan.style.userSelect = 'none';
                if (nameSpan.textContent.trim() === '') {
                    nameSpan.textContent = 'Untitled Folder';
                }
                saveAllItems();
            }
        });

        nameSpan.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                nameSpan.blur();
            }
        });
    });

    addBookmarkBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            const activeTab = tabs[0];
            const bookmarkElement = createBookmarkElement(activeTab.title, activeTab.url, activeTab.favIconUrl);
            bookmarksContainer.insertBefore(bookmarkElement, bookmarksContainer.firstChild);
            saveAllItems();
        });
    });

    editBtn.innerHTML = `<i class="fas fa-edit"></i>`;

    editBtn.addEventListener('click', () => {
        editing = !editing;

        if (editing) {
            addBookmarkBtn.style.display = 'none';
            addFolderBtn.style.display = 'none';
            editBtn.innerHTML = `<i class="far fa-check-circle" style="margin-right: 8px;"></i> Done`;
            editBtn.style.backgroundColor = '#FFA500';
            editBtn.style.color = '#fff';
            editBtn.style.fontWeight = 'bold';
            editBtn.style.fontSize = '14px';
            editBtn.style.padding = '4px 12px';
            editBtn.style.borderRadius = '4px';
        } else {
            addBookmarkBtn.style.display = '';
            addFolderBtn.style.display = '';
            editBtn.innerHTML = `<i class="fas fa-edit"></i>`;
            editBtn.style = '';
        }

        bookmarksContainer.querySelectorAll('.folder-name').forEach(el => {
            el.contentEditable = editing;
            el.style.cursor = editing ? 'text' : 'default';
            editing ? setHoverEffect(el) : removeHoverEffect(el);

            if (editing) {
                el.addEventListener('keypress', folderNameKeyPressHandler);
                el.addEventListener('blur', folderNameBlurHandler);
            } else {
                el.removeEventListener('keypress', folderNameKeyPressHandler);
                el.removeEventListener('blur', folderNameBlurHandler);
            }
        });
        bookmarksContainer.querySelectorAll('.bookmark-title').forEach(el => {
            el.contentEditable = editing;
            el.style.cursor = editing ? 'text' : 'pointer';
            editing ? setHoverEffect(el) : removeHoverEffect(el);

            if (editing) {
                el.addEventListener('keypress', bookmarkTitleKeyPressHandler);
                el.addEventListener('blur', bookmarkTitleBlurHandler);
            } else {
                el.removeEventListener('keypress', bookmarkTitleKeyPressHandler);
                el.removeEventListener('blur', bookmarkTitleBlurHandler);
            }
        });

            // Handler functions (define them outside this event listener)
        function folderNameKeyPressHandler(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                e.target.blur();
            }
        }
        function folderNameBlurHandler(e) {
            e.target.contentEditable = false;
            e.target.style.cursor = 'default';
            e.target.style.userSelect = 'none';
            if (e.target.textContent.trim() === '') {
                e.target.textContent = 'Untitled Folder';
            }
            saveAllItems();
        }
        function bookmarkTitleKeyPressHandler(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                e.target.blur();
            }
        }
        function bookmarkTitleBlurHandler(e) {
            if (!editing) {
                e.target.contentEditable = false;
                e.target.style.cursor = 'pointer';
            }
            saveAllItems();
        }

        bookmarksContainer.querySelectorAll('.delete-btn').forEach(btn => {
            btn.style.display = editing ? 'inline' : 'none';
        });

        // Make the drag icons visible/invisible based on edit mode
        bookmarksContainer.querySelectorAll('.fas.fa-grip-vertical').forEach(dragIcon => {
            dragIcon.style.visibility = editing ? 'visible' : 'hidden';
        });
        bookmarksContainer.querySelectorAll('.bookmark-item.folder').forEach(folderItem => {

        const trashBinIcon = folderItem.querySelector('.fas.fa-trash');
        if (trashBinIcon) {
            trashBinIcon.style.display = editing ? 'inline-block' : 'none';
            if (editing) {
                trashBinIcon.style.marginRight = '-5px';  // Add some right margin when in edit mode
            } else {
                trashBinIcon.style.marginRight = '';  // Reset to default when not in edit mode
            }
        }
        });
    });

    loadItems();

/* ---------------------------------- */
/* -------------- ADD ----------------*/
/* ------ Notion-style Drag ---------*/
/* ---------------------------------- */

    // Variables for drag state
    let dragItem = null;
    let dragIconClone = null;
    let dropLine = null;
    let dragOverTarget = null;
    let dragInsertBefore = false;
    let mouseOffsetY = 0;
    let dropIntoFolder = false;
    let folderElement = null;
    let dragTargetFolder = null;

    function createDropLine() {
        const line = document.createElement('div');
        line.style.position = 'absolute';
        line.style.height = '2px';
        line.style.backgroundColor = '#00aaff';
        line.style.width = 'calc(100% - 20px)';
        line.style.left = '10px';
        line.style.borderRadius = '1px';
        line.style.pointerEvents = 'none';
        line.style.zIndex = '10000';
        return line;
    }

    function onDragMouseDown(e) {
        if (!editing) return;
        if (!e.target.classList.contains('fa-grip-vertical')) return;

        e.preventDefault();

        dragItem = e.target.closest('.bookmark-item');
        if (!dragItem) return;
        dragItem._originalContainer = dragItem.parentNode;


        const rect = dragItem.getBoundingClientRect();
        mouseOffsetY = e.clientY - rect.top;

        dragIconClone = dragItem.cloneNode(true);
        dragIconClone.style.position = 'fixed';
        dragIconClone.style.pointerEvents = 'none';
        dragIconClone.style.width = rect.width + 'px';
        dragIconClone.style.opacity = '0.8';
        dragIconClone.style.zIndex = '10000';
        dragIconClone.style.left = rect.left + 'px';
        dragIconClone.style.top = (e.clientY - mouseOffsetY) + 'px';
        dragIconClone.style.boxShadow = '0 4px 10px rgba(0,0,0,0.4)';
        dragIconClone.style.borderRadius = '6px';
        dragIconClone.style.backgroundColor = '#222';

        document.body.appendChild(dragIconClone);

        dropLine = createDropLine();
        document.body.appendChild(dropLine);

        window.addEventListener('mousemove', onDragMouseMove);
        window.addEventListener('mouseup', onDragMouseUp);
    }

    function onDragMouseMove(e) {
        if (!dragItem) return;

        dragIconClone.style.top = (e.clientY - mouseOffsetY) + 'px';

        // Clear previous folder highlight
        document.querySelectorAll('.folder-drop-target').forEach(folder => {
            folder.classList.remove('folder-drop-target');
        });

        const cursorX = e.clientX;

        // Determine current container where drag is occurring: either main or folder contents
        let currentContainer = bookmarksContainer;
        const folderContentsUnderCursor = document.elementFromPoint(cursorX, e.clientY).closest('.folder-contents');
        if (folderContentsUnderCursor) {
            currentContainer = folderContentsUnderCursor;
        }

        // Get all bookmark items visible in the current container (folder or main)
        const items = Array.from(currentContainer.querySelectorAll('.bookmark-item'));

        let closest = null;
        let closestDist = Infinity;
        let insertBefore = false;

        dropIntoFolder = false;
        folderElement = null;
        let closestFolder = null;
        let closestFolderDist = Infinity;

        for (const item of items) {
            if (item === dragItem) continue;

            const rect = item.getBoundingClientRect();
            const middleY = rect.top + rect.height / 2;
            const dist = Math.abs(e.clientY - middleY);

            // Indent threshold for deciding folder drop, adjust if needed
            const indentThreshold = rect.left + 30;

            // Check if this item is a folder and if cursor is to the right of indent threshold (for folder drop)
            if (item.classList.contains('folder') && cursorX > indentThreshold) {
                if (dist < closestFolderDist) {
                    closestFolderDist = dist;
                    closestFolder = item;
                }
            }

            // For general insert positioning in the current container
            if (dist < closestDist) {
                closestDist = dist;
                closest = item;
                insertBefore = e.clientY < middleY;
            }
        }

        // Decide drop behavior: into folder OR reorder in current container
        if (closestFolder) {
            dropIntoFolder = true;
            folderElement = closestFolder;

            const rect = folderElement.getBoundingClientRect();
            dropLine.style.top = rect.bottom + 'px';
            dropLine.style.left = (rect.left + 30) + 'px';
            dropLine.style.width = (rect.width - 40) + 'px';
            dropLine.style.display = 'block';

            folderElement.classList.add('folder-drop-target');

            dragOverTarget = null; // No reorder target when dropping into folder
            return;
        }

        // If no closest item (empty container), hide drop line and reset
        if (!closest) {
            dropLine.style.display = 'none';
            dragOverTarget = null;
            return;
        }

        // Show drop line for reorder in current container
        dragOverTarget = closest;
        dragInsertBefore = insertBefore;

        const targetRect = closest.getBoundingClientRect();
        dropLine.style.top = insertBefore ? targetRect.top + 'px' : targetRect.bottom + 'px';
        dropLine.style.left = targetRect.left + 'px';
        dropLine.style.width = targetRect.width + 'px';
        dropLine.style.display = 'block';
    }

    function onDragMouseUp(e) {
        if (!dragItem) return;

        if (dragIconClone && dragIconClone.parentNode) {
            dragIconClone.parentNode.removeChild(dragIconClone);
        }
        if (dropLine && dropLine.parentNode) {
            dropLine.parentNode.removeChild(dropLine);
        }

        if (dropIntoFolder && folderElement) {
            const contents = folderElement.querySelector('.folder-contents');
            if (contents) {
                contents.appendChild(dragItem);

                // Remove "Empty" label if it exists inside folder
                const emptyLabel = [...contents.children].find(child => child.textContent.trim() === 'Empty');
                if (emptyLabel) emptyLabel.remove();

                saveAllItems();
            }
        } else if (dragOverTarget) {
            const container = dragOverTarget.parentNode;

            if (dragInsertBefore) {
                container.insertBefore(dragItem, dragOverTarget);
            } else {
                container.insertBefore(dragItem, dragOverTarget.nextSibling);
            }
            saveAllItems();
        } else {
            // If dropped outside any target, put back where it was or fallback to main container end
            bookmarksContainer.appendChild(dragItem);
            saveAllItems();
        }

        // Show "Empty" label if original folder is now empty
        if (
            dragItem._originalContainer &&
            dragItem._originalContainer.classList.contains('folder-contents') &&
            dragItem._originalContainer.children.length === 0
        ) {
            const emptyLabel = document.createElement('div');
            emptyLabel.textContent = 'Empty';
            emptyLabel.style.color = 'rgba(255, 255, 255, 0.4)';
            emptyLabel.style.marginLeft = '20px';
            emptyLabel.style.marginTop = '10px';
            dragItem._originalContainer.appendChild(emptyLabel);
        }

        dragItem = null;
        dragIconClone = null;
        dropLine = null;
        dragOverTarget = null;
        dropIntoFolder = false;
        folderElement = null;

        window.removeEventListener('mousemove', onDragMouseMove);
        window.removeEventListener('mouseup', onDragMouseUp);
    }



    bookmarksContainer.addEventListener('mousedown', onDragMouseDown);

});