chrome.runtime.onInstalled.addListener(() => {
    chrome.storage.local.get(['bookmarks', 'folders'], (res) => {
      if (!res.bookmarks) {
        chrome.storage.local.set({ bookmarks: [] });
      }
      if (!res.folders) {
        chrome.storage.local.set({ folders: [] });
      }
    });
  });