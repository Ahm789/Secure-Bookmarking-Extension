// options.js
document.addEventListener('DOMContentLoaded', () => {
  const changePasswordForm = document.getElementById('changePasswordForm');

  if (changePasswordForm) {
    changePasswordForm.addEventListener('submit', function (e) {
      e.preventDefault();

      const currentPassword = document.getElementById('currentPassword').value.trim();
      const newPassword = document.getElementById('newPassword').value.trim();
      const confirmPassword = document.getElementById('confirmPassword').value.trim();

      const savedPassword = localStorage.getItem('savedPassword');

      if (currentPassword !== savedPassword) {
        alert('Current password is incorrect.');
        return;
      }

      if (newPassword !== confirmPassword) {
        alert('New passwords do not match.');
        return;
      }

      if (newPassword === '') {
        alert('Password cannot be empty.');
        return;
      }

      localStorage.setItem('savedPassword', newPassword);
      alert('Password changed successfully.');
      changePasswordForm.reset();
      
    });
  }
  const toggleButtons = document.querySelectorAll(".toggle-button");
  const saveButton = document.getElementById("saveViewMode");

  // Load previously saved mode
  const savedMode = localStorage.getItem("viewMode");
  if (savedMode) {
    toggleButtons.forEach(btn => {
      btn.classList.toggle("active", btn.dataset.mode === savedMode);
    });
  }

  // Toggle UI
  toggleButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      toggleButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  // Save selected mode
  saveButton.addEventListener("click", () => {
    const selected = document.querySelector(".toggle-button.active");
    if (selected) {
      localStorage.setItem("viewMode", selected.dataset.mode);
      alert(`View mode saved as "${selected.dataset.mode}"`);
    }
  });
});
